import React from "react";
import Landing from "./landing";

export default function index() {
  return (
   <Landing />
  );
}
